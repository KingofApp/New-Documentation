describe('openweathermap controller', function(){
  beforeEach(function() {
    browser.driver.manage().window().setSize(400, 666);
    browser.get('http://localhost:8080/#/menu-abcd/spinner-visualizer');
  });

  it('should load module', function() {
    expect(element(by.css('.spinnerVisualizer'))).toBeDefined();
  });

  it('should load the spinner', function(){
    expect(element(by.css('.transitionloader'))).toBeDefined();
  });
});
