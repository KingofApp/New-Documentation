(function() {
  'use strict';

  angular
    .module('spinnerVisualizer', [])
    .controller('spinnerVisualizerController', loadFunction);

  loadFunction.$inject = ['$scope', 'structureService', '$location'];

  function loadFunction($scope, structureService, $location) {
    // Register upper level modules
    structureService.registerModule($location, $scope, 'spinnerVisualizer');
    // --- Start spinnerVisualizerController content ---
    structureService.launchSpinner('.transitionloader');
    // --- End spinnerVisualizerController content ---
  }
}());
