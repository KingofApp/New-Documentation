# spinner-visualizer Module
===================================

### Description

Spinner Visualizer. This is module was made for King of App Visualizer only.

### Visualizer integration
- app/core/structure.json
```
"modules": {
    "/menu-abcd/spinner-visualizer": {
      "name": "Spinner!",
      "identifier": "spinner-visualizer",
      "type": "A",
      "icon": "home",
      "showOn": {
        "market": true,
        "dragDrop": true
      },
      "view": "modules/spinner-visualizer/index.html",
      "files": ["modules/spinner-visualizer/controller.js"],
      "scope": {
        "value": ""
      }
    }
}
```

### Details:

- Author: Ulises Gascón
- Version: 0.0.1
- Homepage: http://kingofapp.com